using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.InteropServices;
using Microsoft.Extensions.Logging;
using ModelContextProtocol.Protocol;
using ModelContextProtocol.Server;
using Newtonsoft.Json;
using Siemens.Engineering;
using Siemens.Engineering.HW;
using Siemens.Engineering.HW.Features;
using TiaPortalMcpServer.Models;
using TiaPortalMcpServer.Services;

namespace TiaPortalMcpServer
{
    [McpServerToolType]
    public class DeviceItemTools
    {
        private readonly ILogger<DeviceItemTools> _logger;
        private readonly TiaPortalSessionManager _sessionManager;

        public DeviceItemTools(
            ILogger<DeviceItemTools> logger,
            TiaPortalSessionManager sessionManager)
        {
            _logger = logger;
            _sessionManager = sessionManager;
        }

        [McpServerTool(ReadOnly = true, Idempotent = true, Name = "deviceitems_list"), Description("Enumerate all hardware items (CPU modules, I/O modules, communication processors, power supplies) within a specific device. Returns list of device items with names, type identifiers, and position numbers. Prerequisites: Project must be open, device must exist. Use this to inspect device hardware configuration and module layout before item-specific operations.")]
        public CallToolResult deviceitems_list(
            [Description("Device name")] string deviceName)
        {
            _logger.LogInformation("deviceitems_list called with deviceName='{DeviceName}'", deviceName);

            try
            {
                var project = _sessionManager.CurrentProject;
                if (project == null)
                {
                    return McpToolResults.From(
                        ToolResponse<object>.CreateError(
                            ErrorCodes.NoProject,
                            "No project is currently open. Use projects_open first."
                        )
                    );
                }

                var device = project.Devices.FirstOrDefault(d => d.Name == deviceName);
                if (device == null)
                {
                    return McpToolResults.From(
                        ToolResponse<object>.CreateError(
                            ErrorCodes.DeviceNotFound,
                            $"Device '{deviceName}' not found in project"
                        )
                    );
                }

                var deviceItems = device.DeviceItems.Select(item => new
                {
                    name = item.Name,
                    typeName = item.TypeIdentifier,
                    position = item.PositionNumber
                    // address = item.Address // TODO: Check if Address property exists
                }).ToList();

                _logger.LogInformation("Found {Count} device items in device '{DeviceName}'", deviceItems.Count, deviceName);

                return McpToolResults.From(
                    ToolResponse<object>.CreateSuccess(new
                    {
                        deviceName = deviceName,
                        deviceItemCount = deviceItems.Count,
                        deviceItems = deviceItems
                    })
                );
            }
            catch (COMException comEx)
            {
                _logger.LogError(comEx, "COM error listing device items for device '{DeviceName}'", deviceName);
                return McpToolResults.From(
                    ToolResponse<object>.CreateError(
                        ErrorCodes.ComError,
                        $"COM error listing device items: {comEx.Message}",
                        comEx.ToString()
                    )
                );
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error listing device items for device '{DeviceName}'", deviceName);
                return McpToolResults.From(
                    ToolResponse<object>.CreateError(
                        ErrorCodes.TiaError,
                        $"Error listing device items: {ex.Message}",
                        ex.ToString()
                    )
                );
            }
        }

        [McpServerTool(ReadOnly = true, Idempotent = true, Name = "deviceitems_get_attributes"), Description("Retrieve configuration attributes for a specific hardware item within a device including name, type identifier, and position number. Returns attribute object. Prerequisites: Project must be open, device and device item must exist. Use this to inspect individual module properties for configuration validation or hardware inventory.")]
        public CallToolResult deviceitems_get_attributes(
            [Description("Device name")] string deviceName,
            [Description("Device item name")] string deviceItemName)
        {
            _logger.LogInformation("deviceitems_get_attributes called with deviceName='{DeviceName}', deviceItemName='{DeviceItemName}'", deviceName, deviceItemName);

            try
            {
                var project = _sessionManager.CurrentProject;
                if (project == null)
                {
                    return McpToolResults.From(
                        ToolResponse<object>.CreateError(
                            ErrorCodes.NoProject,
                            "No project is currently open. Use projects_open first."
                        )
                    );
                }

                var device = project.Devices.FirstOrDefault(d => d.Name == deviceName);
                if (device == null)
                {
                    return McpToolResults.From(
                        ToolResponse<object>.CreateError(
                            ErrorCodes.DeviceNotFound,
                            $"Device '{deviceName}' not found in project"
                        )
                    );
                }

                var deviceItem = device.DeviceItems.FirstOrDefault(di => di.Name == deviceItemName);
                if (deviceItem == null)
                {
                    return McpToolResults.From(
                        ToolResponse<object>.CreateError(
                            ErrorCodes.DeviceItemNotFound,
                            $"Device item '{deviceItemName}' not found in device '{deviceName}'"
                        )
                    );
                }

                var attributes = new
                {
                    name = deviceItem.Name,
                    typeIdentifier = deviceItem.TypeIdentifier,
                    positionNumber = deviceItem.PositionNumber
                    // address = deviceItem.Address // TODO: Check if Address property exists
                };

                return McpToolResults.From(
                    ToolResponse<object>.CreateSuccess(attributes)
                );
            }
            catch (COMException comEx)
            {
                _logger.LogError(comEx, "COM error getting attributes for device item '{DeviceItemName}' in device '{DeviceName}'", deviceItemName, deviceName);
                return McpToolResults.From(
                    ToolResponse<object>.CreateError(
                        ErrorCodes.ComError,
                        $"COM error getting device item attributes: {comEx.Message}",
                        comEx.ToString()
                    )
                );
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting attributes for device item '{DeviceItemName}' in device '{DeviceName}'", deviceItemName, deviceName);
                return McpToolResults.From(
                    ToolResponse<object>.CreateError(
                        ErrorCodes.TiaError,
                        $"Error getting device item attributes: {ex.Message}",
                        ex.ToString()
                    )
                );
            }
        }

        [McpServerTool(ReadOnly = true, Idempotent = true, Name = "catalog_search_device_items"), Description("Search the TIA Portal hardware catalog for hardware modules and components by query string (order numbers, product names, or partial matches). Returns matching catalog entries with order numbers and descriptions. No prerequisites. Status: NOT IMPLEMENTED. Placeholder for future catalog search integration. Use devices_search_catalog as alternative for device-level catalog search.")]
        public CallToolResult catalog_search_device_items(
            [Description("Search query (e.g., 'CPU', '6ES7', order number)")] string query,
            [Description("Maximum number of results to return")] int maxResults = 10)
        {
            _logger.LogInformation("catalog_search_device_items called with query='{Query}', maxResults={MaxResults}", query, maxResults);

            try
            {
                // Catalog search does not require an open project
                return McpToolResults.From(
                    ToolResponse<object>.CreateSuccess(new
                    {
                        query = query,
                        resultCount = 0,
                        results = Array.Empty<object>(),
                        message = "Hardware catalog search is not yet connected to TIA Portal."
                    })
                );
            }
            catch (COMException comEx)
            {
                _logger.LogError(comEx, "COM error searching hardware catalog with query '{Query}'", query);
                return McpToolResults.From(
                    ToolResponse<object>.CreateError(
                        ErrorCodes.ComError,
                        $"COM error searching catalog: {comEx.Message}",
                        comEx.ToString()
                    )
                );
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error searching hardware catalog with query '{Query}'", query);
                return McpToolResults.From(
                    ToolResponse<object>.CreateError(
                        ErrorCodes.TiaError,
                        $"Error searching catalog: {ex.Message}",
                        ex.ToString()
                    )
                );
            }
        }
        public CallToolResult deviceitems_plug_new(
            [Description("Device name")] string deviceName,
            [Description("Device item order number (e.g., '6ES7 315-2AG10-0AB0')")] string orderNumber,
            [Description("Position number for the device item")] int position,
            [Description("Address for the device item (optional)")] string? address = null,
            [Description("Whether to perform a dry run (true = validate only, false = plug device item)")] bool dryRun = false)
        {
            _logger.LogInformation("deviceitems_plug_new called with deviceName='{DeviceName}', orderNumber='{OrderNumber}', position={Position}, address='{Address}', dryRun={DryRun}", deviceName, orderNumber, position, address, dryRun);

            try
            {
                var project = _sessionManager.CurrentProject;
                if (project == null)
                {
                    return McpToolResults.From(
                        ToolResponse<object>.CreateError(
                            ErrorCodes.NoProject,
                            "No project is currently open. Use projects_open first."
                        )
                    );
                }

                var device = project.Devices.FirstOrDefault(d => d.Name == deviceName);
                if (device == null)
                {
                    return McpToolResults.From(
                        ToolResponse<object>.CreateError(
                            ErrorCodes.DeviceNotFound,
                            $"Device '{deviceName}' not found in project"
                        )
                    );
                }

                if (dryRun)
                {
                    return McpToolResults.From(
                        ToolResponse<object>.CreateSuccess(new
                        {
                            deviceName = deviceName,
                            orderNumber = orderNumber,
                            position = position,
                            address = address,
                            message = "Dry run successful: Device item plugging validation not fully implemented",
                            dryRun = true
                        })
                    );
                }

                // TODO: Implement actual plugging using TIA API
                // var deviceItem = device.PlugNew(orderNumber, position, address);
                return McpToolResults.From(
                    ToolResponse<object>.CreateError(
                        ErrorCodes.NotImplemented,
                        "Device item plugging requires hardware catalog integration. Use dry-run mode to validate parameters."
                    )
                );
            }
            catch (COMException comEx)
            {
                _logger.LogError(comEx, "COM error plugging device item into device '{DeviceName}'", deviceName);
                return McpToolResults.From(
                    ToolResponse<object>.CreateError(
                        ErrorCodes.ComError,
                        $"COM error plugging device item: {comEx.Message}",
                        comEx.ToString()
                    )
                );
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error plugging device item into device '{DeviceName}'", deviceName);
                return McpToolResults.From(
                    ToolResponse<object>.CreateError(
                        ErrorCodes.TiaError,
                        $"Error plugging device item: {ex.Message}",
                        ex.ToString()
                    )
                );
            }
        }

        [McpServerTool(Destructive = true, OpenWorld = true, Name = "deviceitems_plug_move"), Description("Move a device item to a new position")]
        public CallToolResult deviceitems_plug_move(
            [Description("Device name")] string deviceName,
            [Description("Device item name")] string deviceItemName,
            [Description("New position number")] int newPosition,
            [Description("New address (optional)")] string? newAddress = null,
            [Description("Whether to perform a dry run (true = validate only, false = move device item)")] bool dryRun = false)
        {
            _logger.LogInformation("deviceitems_plug_move called with deviceName='{DeviceName}', deviceItemName='{DeviceItemName}', newPosition={NewPosition}, newAddress='{NewAddress}', dryRun={DryRun}", deviceName, deviceItemName, newPosition, newAddress, dryRun);

            try
            {
                var project = _sessionManager.CurrentProject;
                if (project == null)
                {
                    return McpToolResults.From(
                        ToolResponse<object>.CreateError(
                            ErrorCodes.NoProject,
                            "No project is currently open. Use projects_open first."
                        )
                    );
                }

                var device = project.Devices.FirstOrDefault(d => d.Name == deviceName);
                if (device == null)
                {
                    return McpToolResults.From(
                        ToolResponse<object>.CreateError(
                            ErrorCodes.DeviceNotFound,
                            $"Device '{deviceName}' not found in project"
                        )
                    );
                }

                var deviceItem = device.DeviceItems.FirstOrDefault(di => di.Name == deviceItemName);
                if (deviceItem == null)
                {
                    return McpToolResults.From(
                        ToolResponse<object>.CreateError(
                            ErrorCodes.DeviceItemNotFound,
                            $"Device item '{deviceItemName}' not found in device '{deviceName}'"
                        )
                    );
                }

                if (dryRun)
                {
                    return McpToolResults.From(
                        ToolResponse<object>.CreateSuccess(new
                        {
                            deviceName = deviceName,
                            deviceItemName = deviceItemName,
                            newPosition = newPosition,
                            newAddress = newAddress,
                            message = "Dry run successful: Device item move validation not fully implemented",
                            dryRun = true
                        })
                    );
                }

                // TODO: Implement actual move using TIA API
                // deviceItem.MoveTo(newPosition, newAddress);
                return McpToolResults.From(
                    ToolResponse<object>.CreateError(
                        ErrorCodes.NotImplemented,
                        "Device item moving not implemented yet."
                    )
                );
            }
            catch (COMException comEx)
            {
                _logger.LogError(comEx, "COM error moving device item '{DeviceItemName}' in device '{DeviceName}'", deviceItemName, deviceName);
                return McpToolResults.From(
                    ToolResponse<object>.CreateError(
                        ErrorCodes.ComError,
                        $"COM error moving device item: {comEx.Message}",
                        comEx.ToString()
                    )
                );
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error moving device item '{DeviceItemName}' in device '{DeviceName}'", deviceItemName, deviceName);
                return McpToolResults.From(
                    ToolResponse<object>.CreateError(
                        ErrorCodes.TiaError,
                        $"Error moving device item: {ex.Message}",
                        ex.ToString()
                    )
                );
            }
        }

        [McpServerTool(Destructive = true, OpenWorld = true, Name = "deviceitems_copy"), Description("Copy a device item to a new position")]
        public CallToolResult deviceitems_copy(
            [Description("Device name")] string deviceName,
            [Description("Device item name to copy")] string sourceDeviceItemName,
            [Description("New position number")] int newPosition,
            [Description("New address (optional)")] string? newAddress = null,
            [Description("Whether to perform a dry run (true = validate only, false = copy device item)")] bool dryRun = false)
        {
            _logger.LogInformation("deviceitems_copy called with deviceName='{DeviceName}', sourceDeviceItemName='{SourceDeviceItemName}', newPosition={NewPosition}, newAddress='{NewAddress}', dryRun={DryRun}", deviceName, sourceDeviceItemName, newPosition, newAddress, dryRun);

            try
            {
                var project = _sessionManager.CurrentProject;
                if (project == null)
                {
                    return McpToolResults.From(
                        ToolResponse<object>.CreateError(
                            ErrorCodes.NoProject,
                            "No project is currently open. Use projects_open first."
                        )
                    );
                }

                var device = project.Devices.FirstOrDefault(d => d.Name == deviceName);
                if (device == null)
                {
                    return McpToolResults.From(
                        ToolResponse<object>.CreateError(
                            ErrorCodes.DeviceNotFound,
                            $"Device '{deviceName}' not found in project"
                        )
                    );
                }

                var sourceDeviceItem = device.DeviceItems.FirstOrDefault(di => di.Name == sourceDeviceItemName);
                if (sourceDeviceItem == null)
                {
                    return McpToolResults.From(
                        ToolResponse<object>.CreateError(
                            ErrorCodes.DeviceItemNotFound,
                            $"Source device item '{sourceDeviceItemName}' not found in device '{deviceName}'"
                        )
                    );
                }

                if (dryRun)
                {
                    return McpToolResults.From(
                        ToolResponse<object>.CreateSuccess(new
                        {
                            deviceName = deviceName,
                            sourceDeviceItemName = sourceDeviceItemName,
                            newPosition = newPosition,
                            newAddress = newAddress,
                            message = "Dry run successful: Device item copy validation not fully implemented",
                            dryRun = true
                        })
                    );
                }

                // TODO: Implement actual copy using TIA API
                // var newDeviceItem = sourceDeviceItem.CopyTo(newPosition, newAddress);
                return McpToolResults.From(
                    ToolResponse<object>.CreateError(
                        ErrorCodes.NotImplemented,
                        "Device item copying not implemented yet."
                    )
                );
            }
            catch (COMException comEx)
            {
                _logger.LogError(comEx, "COM error copying device item '{SourceDeviceItemName}' in device '{DeviceName}'", sourceDeviceItemName, deviceName);
                return McpToolResults.From(
                    ToolResponse<object>.CreateError(
                        ErrorCodes.ComError,
                        $"COM error copying device item: {comEx.Message}",
                        comEx.ToString()
                    )
                );
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error copying device item '{SourceDeviceItemName}' in device '{DeviceName}'", sourceDeviceItemName, deviceName);
                return McpToolResults.From(
                    ToolResponse<object>.CreateError(
                        ErrorCodes.TiaError,
                        $"Error copying device item: {ex.Message}",
                        ex.ToString()
                    )
                );
            }
        }

        [McpServerTool(Destructive = true, OpenWorld = true, Name = "deviceitems_delete"), Description("Delete a device item from a device")]
        public CallToolResult deviceitems_delete(
            [Description("Device name")] string deviceName,
            [Description("Device item name")] string deviceItemName,
            [Description("Whether to perform a dry run (true = validate only, false = delete device item)")] bool dryRun = false)
        {
            _logger.LogInformation("deviceitems_delete called with deviceName='{DeviceName}', deviceItemName='{DeviceItemName}', dryRun={DryRun}", deviceName, deviceItemName, dryRun);

            try
            {
                var project = _sessionManager.CurrentProject;
                if (project == null)
                {
                    return McpToolResults.From(
                        ToolResponse<object>.CreateError(
                            ErrorCodes.NoProject,
                            "No project is currently open. Use projects_open first."
                        )
                    );
                }

                var device = project.Devices.FirstOrDefault(d => d.Name == deviceName);
                if (device == null)
                {
                    return McpToolResults.From(
                        ToolResponse<object>.CreateError(
                            ErrorCodes.DeviceNotFound,
                            $"Device '{deviceName}' not found in project"
                        )
                    );
                }

                var deviceItem = device.DeviceItems.FirstOrDefault(di => di.Name == deviceItemName);
                if (deviceItem == null)
                {
                    return McpToolResults.From(
                        ToolResponse<object>.CreateError(
                            ErrorCodes.DeviceItemNotFound,
                            $"Device item '{deviceItemName}' not found in device '{deviceName}'"
                        )
                    );
                }

                if (dryRun)
                {
                    return McpToolResults.From(
                        ToolResponse<object>.CreateSuccess(new
                        {
                            deviceName = deviceName,
                            deviceItemName = deviceItemName,
                            message = "Dry run successful: Device item deletion validation not fully implemented",
                            dryRun = true
                        })
                    );
                }

                // TODO: Implement actual delete using TIA API
                // deviceItem.Delete();
                return McpToolResults.From(
                    ToolResponse<object>.CreateError(
                        ErrorCodes.NotImplemented,
                        "Device item deletion not implemented yet."
                    )
                );
            }
            catch (COMException comEx)
            {
                _logger.LogError(comEx, "COM error deleting device item '{DeviceItemName}' from device '{DeviceName}'", deviceItemName, deviceName);
                return McpToolResults.From(
                    ToolResponse<object>.CreateError(
                        ErrorCodes.ComError,
                        $"COM error deleting device item: {comEx.Message}",
                        comEx.ToString()
                    )
                );
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting device item '{DeviceItemName}' from device '{DeviceName}'", deviceItemName, deviceName);
                return McpToolResults.From(
                    ToolResponse<object>.CreateError(
                        ErrorCodes.TiaError,
                        $"Error deleting device item: {ex.Message}",
                        ex.ToString()
                    )
                );
            }
        }
    }
}
