# TIA Portal MCP Server CLI

CLI to install and manage [TIA Portal MCP Server](https://github.com/chewcw/tia-portal-openness-mcpserver) releases.

## Requirements

- Node.js >= 20
- Windows machine with Siemens TIA Portal V20 installed (for the server)

## Installation

```bash
npm install -g @chewcw/tia-portal-openness-mcpserver
```

Or use directly with npx:

```bash
npx @chewcw/tia-portal-openness-mcpserver <command>
```

## Commands

### `install`

Install latest or selected server release.

```bash
tia-portal-openness-mcpserver install
tia-portal-openness-mcpserver install --server-version v1.0.0
tia-portal-openness-mcpserver install --install-dir /custom/path
```

The install workflow now prompts to install companion skills alongside the MCP server. By default it offers `.agents/skills` as the selected install location and allows choosing a global or local environment.

## Global Options

| Option | Description |
| --- | --- |
| `--server-version <tag>` | Explicit server release tag |
| `--install-dir <path>` | Override default install root |
| `--companion-skills <name[,name...]>` | Install companion skills to selected locations |
| `--companion-skills-path <path>` | Companion skill installation location |
| `--companion-skills-env <global|local>` | Install companion skills into global or local environment |
| `--help` | Show help |
| `--version` | Show CLI version |

## Installation Location

Default: per-user AppData at `%APPDATA%/TiaPortalMcpServerCli/server`

## Environment Variables

| Variable | Description |
| --- | --- |
| `GITHUB_TOKEN` | Token for authenticated GitHub API access |
| `TIA_MCP_INSTALL_DIR` | Override default install directory |
| `TIA_MCP_AGENT_TYPE` | Override agent type detection (`opencode`, `claude`, `cursor`, `generic`) |
| `TIA_MCP_SKILLS_PATH` | Override skills installation path |

The CLI also auto-detects the agent type from runtime environment variables (`OPENCODE_SESSION_ID`, `CLAUDE_AGENT_METADATA_FILE`, `CURSOR_SESSION_ID`).

## License

MIT
